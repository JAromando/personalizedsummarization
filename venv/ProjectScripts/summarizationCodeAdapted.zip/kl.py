from nltk import tokenize
from operator import attrgetter
from utils import ItemsCount
from collections import namedtuple

import re
import math

SentenceInfo = namedtuple("SentenceInfo", ("sentence", "order", "rating",))

class KLSum():

    def __call__(self, text, sentencesCount):
        sentences = tokenize.sent_tokenize(text)
        for i, sentence in enumerate(sentences):
            sentences[i] = re.sub(r"[^a-zA-Z0-9]+", ' ', sentence)
        print(sentences)
        ratings = self.getScores(sentences)
        sentences = tokenize.sent_tokenize(text)
        for i, sentence in enumerate(sentences):
            sentences[i] = re.sub(r"[^a-zA-Z0-9]+", ' ', sentence)
        return self.getBestSentences(sentences, sentencesCount, ratings)

    def getScores(self, sentences):
        ratings = self.computeScores(sentences)
        return ratings

    def getBestSentences(self, sentences, count, rating, *args, **kwargs):
        rate = rating
        if isinstance(rating, dict):
            assert not args and not kwargs
            rate = lambda s: rating[s]

        infos = (SentenceInfo(s, o, rate(s, *args, **kwargs))
            for o, s in enumerate(sentences))

        # sort sentences by rating in descending order
        infos = sorted(infos, key=attrgetter("rating"), reverse=True)
        # get `count` first best rated sentences
        if not isinstance(count, ItemsCount):
            count = ItemsCount(count)
        infos = count(infos)
        # sort sentences by their order in document
        infos = sorted(infos, key=attrgetter("order"))

        return tuple(i.sentence for i in infos)

    def computeScores(self, sentences):
        wordFreq, wordList = self.computeTF(sentences)
        ratings = {}
        summary = []

        # Removes one sentence per iteration by adding to summary
        while len(sentences) > 0:
            print(len(sentences))
            # will store all the kls values for this pass
            kls = []

            # converts summary to word list
            if summary:
                for sent in summary:
                    summaryWordList.append(tokenize.word_tokenize(sent))
            else:
                summaryWordList = []

            for s in wordList:
                # calculates the joint frequency through combining the word lists
                jointFreq = self.computeJointFreq(s, summaryWordList)

                # adds the calculated kl divergence to the list in index = sentence used
                kls.append(self.klDivergence(jointFreq, wordFreq))

            # to consider and then add it into the summary
            indexToRemove = self.getIndexOfBestSentence(kls)
            bestSentence = sentences.pop(indexToRemove)
            del wordList[indexToRemove]
            summary.append(bestSentence)

            # value is the iteration in which it was removed multiplied by -1 so that the first sentences removed (the most important) have highest values
            ratings[bestSentence] = -1 * len(ratings)

        return ratings

    def computeTF(self, sentences):
        results = []
        for s in sentences:
            results.append(tokenize.word_tokenize(s))
        #stop words? normalize?
        wordFrequency = self.computeWordFreq(results)
        return wordFrequency, results

    def computeWordFreq(self, results):
        wordFrequency = {}
        for sentence in results:
            for word in sentence:
                word = word.lower()
                if wordFrequency.get(word) == None:
                    wordFrequency[word] = 1
                else:
                    currFreq = wordFrequency.get(word)
                    wordFrequency[word] = currFreq + 1
        return wordFrequency

    def computeJointFreq(self, sentenceList, summaryWordList):
        # combined length of the word lists
        total_len = len(sentenceList) + len(summaryWordList)

        # word frequencies within each list
        wcSentenceList = self.computeWordFreq(sentenceList)
        wcsSummaryWordList = self.computeWordFreq(summaryWordList)

        # inputs the counts from the first list
        joint = wcSentenceList.copy()

        # adds in the counts of the second list
        for k in wcsSummaryWordList:
            if k in joint:
                joint[k] += wcsSummaryWordList[k]
            else:
                joint[k] = wcsSummaryWordList[k]

        # divides total counts by the combined length
        for k in joint:
            joint[k] /= float(total_len)

        return joint

    def klDivergence(self, summaryFreq, docFreq):
        sum_val = 0
        for w in summaryFreq:
            frequency = docFreq.get(w)
            if frequency:  # missing or zero = no frequency
                sum_val += frequency * math.log(frequency / summaryFreq[w])

        return sum_val

    def getIndexOfBestSentence(self, kls):
        return kls.index(min(kls))