from tika import parser
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
import os
import math

class LanguageModel():

    def computeSentenceProbability(self, sentence):

        LANGUAGE = "english"

        files = [i for i in os.listdir("C:/Users/John/PycharmProjects/SummarizationTests/venv/data") if i.endswith("pdf")]
        corpusFrequency = {}
        corpusLength = 0;

        for file in files:

            raw = parser.from_file("C:/Users/John/PycharmProjects/SummarizationTests/venv/data/" + file)

            for word in raw['content'].split():
                word = word.lower()
                corpusLength += 1
                if corpusFrequency.get(word) == None:
                    corpusFrequency[word] = 1
                else:
                    currFreq = corpusFrequency.get(word)
                    corpusFrequency[word] = currFreq + 1

        corpusProb = {}

        for key, value in corpusFrequency.items():
            corpusProb[key] = value/corpusLength

        '''for item in sorted(corpusProb.items(), key=lambda x: x[1], reverse=True):
            k,v = item
            print(k, v)'''

        sentProb = 0;

        for word in sentence:
            word = word.lower()
            counter = 0
            for _word in sentence:
                if word == _word:
                    counter += 1
            print(word)
            sentProb += counter * math.log(corpusProb.get(word))

        return sentProb

    '''if __name__ == "__main__":

        sent = "The meaning of the term information retrieval can be very broad."
        score = computeSentenceProbability(sent)
        print()
        print("Score: ", score)'''











